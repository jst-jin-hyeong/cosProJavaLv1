
public class Examint {
	 public static void main(String[] args){
		 int x1=10000;
		 int x2=10000000;
		 
		 System.out.println(x1*x1);
		 System.out.println(x2*x2);
		 
	 }
}
