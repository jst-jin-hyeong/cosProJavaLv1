
public class ExamMath {

	public static void main(String[] args) {
	
	for (int i=0 ; i<10; i++)
		System.out.println( Math.random() );

	
	for (int i=0 ; i<10; i++)
		System.out.println((int)( Math.random()*100 ) );
	 	
	}

}
