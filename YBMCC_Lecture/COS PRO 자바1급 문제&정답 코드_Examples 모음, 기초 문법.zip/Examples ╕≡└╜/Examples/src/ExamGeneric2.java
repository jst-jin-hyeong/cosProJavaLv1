import java.util.ArrayList;

public class ExamGeneric2 {
	public static void main(String[] args) {
//	   ArrayList arrlist= new ArrayList();
	   
//	   arrlist.add(1);
//	   arrlist.add(2);
//	   arrlist.add("3");
//	   String str = (String)arrlist.get(2);
//		

	   
//	   ArrayList<Integer> arrlist= new ArrayList<Integer>();
//	   
//	   arrlist.add(1);
//	   arrlist.add(2);
//	   arrlist.add("3");  //������ ����
//	   System.out.println(arrlist);		

	   
	   
//	   ArrayList arrlist= new ArrayList();
//	   
//	   arrlist.add(1);
//	   arrlist.add(2);
//	   arrlist.add(3);
//	   Integer var1 = (Integer)arrlist.get(2);
//	
	   
//	   
	   ArrayList<Integer> arrlist= new ArrayList<Integer>();
	   
	   arrlist.add(1);
	   arrlist.add(2);
	   arrlist.add(3);  
	   Integer var2 = arrlist.get(2);
		
	   System.out.println(var2);
	   
	}
	
}
