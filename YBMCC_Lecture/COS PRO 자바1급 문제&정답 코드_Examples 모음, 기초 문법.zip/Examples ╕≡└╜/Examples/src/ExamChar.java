
public class ExamChar {

	public static void main(String[] args) {
		
		System.out.println((int)('A'));
		System.out.println((int)('0'));
		
		
		String s="ABC";
		System.out.println(s.charAt(0));
		System.out.println(s.charAt(1));
		
		System.out.println(s.charAt(0)-'A');
		System.out.println(s.charAt(1)-'A');
		
		
		char c='A';
		System.out.println(c-'A');
		
				
		char i='3';
		System.out.println(i-'1');
	}

}
