
public class ExamSubstr {
	public static void main(String[] args) {
		
		String exp="123+12";
		
        System.out.println(exp.substring(2));
        System.out.println(exp.substring(1,4));
        
		
	}
}
