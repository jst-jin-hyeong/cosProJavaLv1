import java.lang.*;

public class ExamWrapper {

	public static void main(String[] args) {
		Integer i = 10;
		Integer ivar = new Integer(100);
	
		System.out.println(i);
		System.out.println(ivar);
		
		String s="100";
		
		int par = Integer.parseInt("100");
		
		System.out.println(par+10);

	}

}
