/*=======================================
    1�� 2��   1�� 1�� 2_initial_code.java
 ========================================*/

// You may use import as below.
//import java.util.*;

class Solution {
    public int solution(int n) {
        // Write code here.
        int answer = 0;
        return answer;
    }

    // The following is main method to output testcase.
    public static void main(String[] args) {
        Solution sol = new Solution();
        int n1 = 3;
        int ret1 = sol.solution(n1);
        
        // Press Run button to receive output. 
        System.out.println("Solution: return value of the method is " + ret1 + " .");
        
        int n2 = 2;
        int ret2 = sol.solution(n2);
        
        // Press Run button to receive output. 
        System.out.println("Solution: return value of the method is " + ret2 + " .");
    }
}

